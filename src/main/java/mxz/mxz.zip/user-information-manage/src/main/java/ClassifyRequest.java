import controller.AddressController;
import controller.UserController;
import entity.Address;

public class ClassifyRequest {
    private static UserController userController;
    private static AddressController addressController;
    static {
        userController = new UserController();
        addressController = new AddressController();

    }
    public static void main(String[] args) {
      while (true) {
          exRequest();
      }
    }

    static public void exRequest(){
        java.util.Scanner s = new java.util.Scanner(System.in);
        System.out.println("输入服务类型：");
        String request = s.next();
    switch (request){

        case "添加地址":
            System.out.println("请输入地址：");
            String address = s.next();
            addressController.add(new Address());
            break;
        case "上传审核信息":
            System.out.println("请输入审核信息：");

            break;
    }
    }
}

