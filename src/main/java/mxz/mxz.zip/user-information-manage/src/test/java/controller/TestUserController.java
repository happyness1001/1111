package controller;

import entity.Client;
import entity.Store;
import entity.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestUserController {
    String path = "springmvc.xml";
    @Test
    public void testRegister(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(path);
        UserController userController = (UserController) applicationContext.getBean("userController");
        User client = new User();
        client.setUserType(3);
        client.setName("测试");
        client.setPassword("1111");
//        ClientService clientService = (ClientService) applicationContext.getBean("clientService");
//        Client client1 = clientService.findByName("小秒");
//        System.out.println(client1);
//
    }

    @Test
    public void testLogin(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(path);
        UserController userController = (UserController) applicationContext.getBean("userController");
        Store store = new Store();
        store.setUserType(2);
        store.setName("羊咩咩1");
        store.setPassword("158159");
//        ClientService clientService = (ClientService) applicationContext.getBean("clientService");
//        Client client1 = clientService.findByName("小秒");
//        System.out.println(client1);
//
    }
}
