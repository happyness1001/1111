package service;

import entity.Client;
import entity.User;
import org.junit.Test;

public class TesstUser {
    @Test
    public void testUser(){
        Client client = new Client();
        client.setUserType(1);
        System.out.println(client.getUserType());
        testUser1(client);
    }

    public void testUser1(User user){
        System.out.println(user.getUserType());
    }
}
