package controller;

import entity.AuditPage;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAuditController {
    ApplicationContext applicationContext = new ClassPathXmlApplicationContext("WEB-INF/springmvc.xml");
    AuditController auditController = (AuditController) applicationContext.getBean("auditController");
    @Test
    public void testAdd(){
        AuditPage auditPage = new AuditPage();
        auditPage.setUid("test");
        auditPage.setType(1);
    }

    @Test
    //测试审核功能
    public void testAuditByUserType(){

    }
}
