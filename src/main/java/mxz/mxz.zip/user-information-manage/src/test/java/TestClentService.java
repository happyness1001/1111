
import entity.Client;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import service.impl.ClientServiceImpl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class TestClentService {

//    public Client creatClient(Integer uid,String name,String password,String email,Integer sex){
//        Client client = new Client();
//        client.setUid(uid);
//        client.setName(name);
//        client.setPassword(password);
//        client.setEmail(email);
//        client.setSex(sex);
//        return client;
//    }
//@Test
//    public void testRegister(){
//        Client newClient = creatClient(113,"赵云","1111","12345@qq.com",1);
//
//        ClientService clientService = new ClientServiceImpl();
//        Integer i = clientService.register(newClient);
//            System.out.println(i);
//    }
//
//    @Test
//    public void testUpdate(){
//        Client newClient = creatClient(113,"小杨","1111","12345@qq.com",1);
//        ClientService clientService = new ClientServiceImpl();
//        Integer i = clientService.update(newClient);
//        System.out.println((i == 1)?"刷新成功":"刷新失败");
//    }
//
//    @Test
//    public void testFindById(){
//        ClientService clientService = new ClientServiceImpl();
//        Client client = clientService.findByUid(113);
//        System.out.println(client);
//    }
//
//    @Test
//    public void testDelete(){
//        ClientService clientService = new ClientServiceImpl();
//        Integer i = clientService.delete(113);
//        System.out.println((i == 1)?"删除成功":"删除失败");
//    }

    @Test
    public void testManagerAdd(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("WEB-INF/springmvc.xml");
        ClientServiceImpl clientServiceImpl = (ClientServiceImpl) applicationContext.getBean("clientService");
            Client client  = new Client();
            client.setName("小张");
//            SqlSession sqlSession = MyBatisUtils.getSqlSession();
//            StoreDao Client Dao = sqlSession.getMapper(StoreDao.class);
            clientServiceImpl.register(client);
    }
    @Test
    public void testTime() {
        Date date = new Date();
        System.out.println(date.toString());
        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
        System.out.println(System.currentTimeMillis());
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss:SSS");
        System.out.println(new Timestamp(System.nanoTime()));
        System.out.println(new Timestamp(8705892691110L));
        System.out.println("第一版问题：当纳秒第九位是0时，时间戳会出现15位的情况");
        String timeStamp1 = System.currentTimeMillis() / 1000L +""+ System.nanoTime() / 1000L % 1000000;
        System.out.println(timeStamp1);
        System.out.println("第二版问题：可以稳定生成16位时间戳，但是在毫秒的精度方面还存在一些问题，微秒精度较高");
        Long microsecond = System.nanoTime() / 1000 % 1000000;
        String timeStamp2 = System.currentTimeMillis() / 1000L + (microsecond < 100000?"0":"") + microsecond;
        System.out.println(timeStamp2);
        System.out.println(new Timestamp(System.currentTimeMillis()));
        System.out.println(new Timestamp(new Date().getTime()));
    }
    @Test
    public void study(){

    }
}