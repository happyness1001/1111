package service;

import org.junit.Test;

public class MyMath {
    @Test
    public void Math1(){
        //梯形公式
        double y0 = 0.5;
        System.out.println("k=0时，f(0.1k)=" + y0);
        for (int k = 1; k <=30; k++){
            double y = y0 + 0.05 * (Math.exp(-0.01 * k * k/2) + Math.exp(-0.01 * (k - 1) * (k - 1)/2))/Math.sqrt(2*Math.PI);
            y0 = y;
            System.out.print("k=" + k + "时，f(0.1k)=" + String.format("%.7f", y) + "    " );
            if (k % 5 ==0) System.out.println();
        }
    }
}
