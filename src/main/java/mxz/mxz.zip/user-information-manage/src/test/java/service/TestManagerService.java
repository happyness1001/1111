package service;

import entity.Manager;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestManagerService {
    String path = "WEB-INF/springmvc.xml";
    Manager manager  = new Manager();

    @Test
    public void testRegister(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(path);
        ManagerService managerService = (ManagerService) applicationContext.getBean("managerService");
        manager.setName("小张");
        managerService.register(manager);
    }
}
