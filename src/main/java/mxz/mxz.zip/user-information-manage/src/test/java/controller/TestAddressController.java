package controller;

import entity.Address;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAddressController {
    String path = "WEB-INF/springmvc.xml";
    @Test
    public void testAdd(){
        Address address = new Address();
        address.setUid("11111");
        address.setProvince("辽宁省");
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(path);
        AddressController addressController = (AddressController) applicationContext.getBean("addressController");
        addressController.add(address);
    }
    @Test
    public void testSetDefault(){
        Address address = new Address();
        address.setUid("11111");
        address.setProvince("辽宁省");
        address.setAddressId(1);
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(path);
        AddressController addressController = (AddressController) applicationContext.getBean("addressController");
        addressController.setDefaultAddress(address);
    }
}
