package service;

import entity.Provider;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestProviderService {
    String path = "WEB-INF/springmvc.xml";
    Provider provider  = new Provider();


    @Test
    public void testRegister(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext(path);
        ProviderService providerService = (ProviderService) applicationContext.getBean("providerService");
        provider.setName("小张");
        providerService.register(provider);
    }
}
